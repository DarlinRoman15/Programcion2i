#Calcular cuantos años le faltan al usario para cumplir 100 años y muestra ese dato.
edad= int(input("¿cuantos años me faltan para llegar a cumplir 100 años?,introduce tu edad:"))
Año= 100
resta= Año-edad
print("los años que me faltan para cumplir 100 años son",resta)