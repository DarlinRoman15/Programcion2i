numero = 1 
numero2 = 2 
suma = numero + numero2 
print("respuesta", suma) 