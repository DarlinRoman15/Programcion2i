# 3. Convertir datos de input a enteros
num = int(input("Ingresa un número entero: "))
print(f"El número ingresado como entero es: {num}")