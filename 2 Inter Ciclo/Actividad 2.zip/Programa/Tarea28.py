#Cuenta cuantas letras hay en una palabra
nombre = "Darlin"
contador=0
for i in nombre:
    contador=contador + 1
    print(i)
print("Numero de letras es: ",contador)

#3 remplaza las vocales por asteriscos
nombre = input("ponga su nombre: ")
for i in nombre:
    if i == "a" or i == "e" or i == "i" or i == "o" or i == "u":
        nombre = nombre.replace(i, "*")
print(nombre)
