num0= 0
num1= 1
num2= 2
num3= 3
num4= 4

print("numeros", num0, num1, num2, num3, num4)

#Imprimir numeros del 0 al 4

for i in range(10):
    print("numero: ",i)