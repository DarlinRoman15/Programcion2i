# Ingrese tres notas del estudiante y calcula su promedio
# Luego identifica si pasa o no el año con la siguiente escala
# Menor a 50 Reprueba
# Entre 60 y 70 Regular
# Entre 80 y 89 Buena
# Entre 90 y 100 Excelente

nota1 = float(input("Ingrese Nota 1: "))
nota2 = float(input("Ingrese Nota 2: "))
nota3 = float(input("Ingrese Nota 3: "))

promedio = (nota1 + nota2 + nota3) / 3

if promedio < 60:
    estado = "Reprueba"
elif promedio < 80:
    estado = "Regular"
elif promedio < 90:
    estado = "Buena"
else:
    estado = "Excelente"

print(f"Promedio: {promedio:.2f}, Estado: {estado}")