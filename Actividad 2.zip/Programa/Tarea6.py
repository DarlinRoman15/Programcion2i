nombre = input("Cual es tu nombre")
print("Hola, " + nombre)