numero = [1 , 2 , 3 , 4 , 5 , 5 , 6 , 7 , 8 , 9 , 10]
for x in numero:
    print("lista: ",x)