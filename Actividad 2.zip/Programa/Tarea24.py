for i in "Yanky":
    if (i == "a"):
       print(i)