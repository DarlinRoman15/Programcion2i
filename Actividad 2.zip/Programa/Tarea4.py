#concatenacion
a = "Hola"
b = "Buenos dias"
print (a + b) 