# 1. Pedir un nombre y saludar
nombre = input("Ingresa tu nombre: ")
print(f"Hola, {nombre}!")









