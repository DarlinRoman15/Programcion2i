#imprimir con formato
nombre = "Darlin"
edad = 21 
print(f"Me llamo {nombre} y tengo {edad}.")