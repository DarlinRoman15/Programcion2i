#imprime todos los elementos de una lista de frutas
frutas = ["manzana", "pera", "durazno", "uva", "mango", "kiwi", "sandia"]
for i in frutas:
    print(i)
print("\n")

#calcula la suma de una lista de numeros 
x=0
for i in range(1,11):
     x += i
     print(f"la lista es: {i}")
     print(x)
print("\n")

#muestra los nombres de los estudiantes en un curso
Nombres = ["Micha", "Michelle", "Dumaguala", "Quitu", "Maria", "Karla", "Samanta"]
for i in Nombres:
    print(i)
print("\n")

#indica cuantas palabras hay con mas de 5 letras 
palabra = ["casa", "elefante", "quituisaca", "comer", "pera", "ahuacate", "computadora"]
contador = 0
for i in palabra:
    if len(i)>5:
        contador +=1 
        print(i)
print("\n4. Palabras con mas de 5 letras: ",contador)
print("\n")
#imprime el doble de cada numero en la lista 
numeros = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
for i in numeros:
    doble = i * 2
    print(f"El doble de {i} es {doble}")
print("\n")

#muestra solo los elementos que contienen las letra "a"
palabras = ["manzana", "pera", "uva", "banana", "kiwi", "mango", "durazno", "aguacate", "control"]
for palabra in palabras:
    if "a" in palabra:
        print(palabra)
print("\n")

#determina cuantos numeros son mayores que 50
numeros = [23, 67, 89, 45, 12, 55, 100, 49]
contador = 0
for numero in numeros:
    if numero > 50:
        contador += 1
        print(f"el numero es {numero}")
print(f"Hay {contador} números mayores que 50.")

#crea una lista con los cuadros de los elementos originales
numeros = [2, 4, 6, 8, 10]
cuadrados = []
for numero in numeros:
    cuadrados.append(numero ** 2)
print("Lista original:", numeros)
print("Cuadrados:", cuadrados)
print("\n")

#filtra y muestra solo los elementos que sean srtrings 
elementos = [42, "josue", True, "planeta", 3.14, "universo", None]
for elemento in elementos:
    if isinstance(elemento, str):
        print(elemento)
print("\n")

#cambia todos los nombres a mayuscula
nombres = ["ana", "pedro", "lucía", "mario", "elena"]
nombres_mayuscula = []
for nombre in nombres:
    nombres_mayuscula.append(nombre.upper())
print("Nombres en mayúsculas:", nombres_mayuscula)