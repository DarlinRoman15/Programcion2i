# 5. Calcular el área de un rectángulo
base = float(input("Ingresa la base del rectángulo: "))
altura = float(input("Ingresa la altura del rectángulo: "))
area = base * altura
print(f"El área del rectángulo es: {area}")