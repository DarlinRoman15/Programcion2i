#ingresa dos numeros y haga la suma
numero1 = input("ingresa tu primero numero")
numero2 = input("ingresa el segundo numero")
suma= int(numero1) +int (numero2)
resta= int(numero1) -int (numero2)
multiplicacion= int(numero1) *int (numero2) 
division= int(numero1) /int (numero2)
print(f"la respuesta es:{suma}, de la resta es; {resta}, de la multiplicacion es: {multiplicacion}, de la division es : {division}")

