#Ingresa un numero y verifica si es positivo o negativo
A = int(input("Ingresa un numero: "))
if A > 0:
    print(f"EL numero es positivo:{A} ")
elif A == 0:
    print("El numero es neutro")
else : 
    print("El numero es negativo: ")
