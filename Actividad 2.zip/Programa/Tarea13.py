x = int(input("ingresa un numero: "))
if x > 5:
    print("x es mayor que 5")
else :
    print("x no es mayor que 5")