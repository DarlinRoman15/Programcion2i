#Adivina un numero
numero_secreto = 7
adivina= int(input("Adivina un numero"))

if adivina == numero_secreto:
    print("Ganaste")
else:
    print("UPS, intenta nuevamente !")