#Menu de comidas (pizza / ensalada / hamburguesa)
comida = input("Que te gustaria comer hoy? (pizza / ensalada / hamburguesa)")
if comida == "pizza":
    print("Buen provecho seleccionaste pizza")
elif comida == "ensalada":
    print("Selecciono: Ensalada")
elif comida == "hamburguesa":
    print("Buen provecho selecciono Hamburguesa")
else :
    print("tu seleccion no esta en el menu")