#imprimir en varias lineas = \n
print("Darlin \n Roman \n 21")