# 2. Pedir dos números y mostrarlos
num1 = float( input("Ingresa el primer número: "))
num2 = float(input("Ingresa el segundo número: "))
print(f"Los números ingresados son: {num1} y {num2}")