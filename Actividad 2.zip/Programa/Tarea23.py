

for i in range(1,100,4):
    print(i)