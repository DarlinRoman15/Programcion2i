numero = 5
numero2 = 8 
suma= numero + numero2
print("respuesta", suma)

resta = numero - numero2
print("respuesta", resta)

multuplicacion = numero * numero2
print("respuesta", multuplicacion)

division = numero / numero2
print("respuesta", division)