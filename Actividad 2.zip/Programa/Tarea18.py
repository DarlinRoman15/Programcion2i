# Ingresa un numero e identifica si es mayor de edad
A = int(input("Ingresa tu edad : "))
if A >= 21:
  print(f"Eres mayor de edad: {A} ")
else :
  print("No eres mayor de edad")


 