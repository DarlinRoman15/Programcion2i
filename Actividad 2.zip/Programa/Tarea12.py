# 6. Dividir dos números
num1 = float(input("Ingresa el dividendo: "))
num2 = float(input("Ingresa el divisor: "))
if num2 != 0:
    division = num1 / num2
    print(f"El resultado de la división es: {division}")
else:
    print("No se puede dividir por cero.")