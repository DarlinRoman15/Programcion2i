#Muestra la tabla de multiplicar del 7.
x = int (input("Ingresa un numero: "))
print(f"Tabla de multiplicar del {x}: ")
for i in range(1,11):
    producto = i * x
    print("producto", producto)