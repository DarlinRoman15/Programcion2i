#1.Imprime los numeros del 1 al 10.
print("Números del 1 al 10:")
for x in range(1,11):
    print(x," ")
print("\n")

#2.Imprime los numeros pares del 2 al 20.
print("Números pares del 2 al 20:")
for x in range(2,22,2):
    print(x," ") 
print("\n") 

#3.Imprime los multiplos de 3 del 0 al 30.
print("Múltiplos de 3 del 0 al 30:")
for x in range(0,33,3):
    print(x," ")
print("\n") 
#4.Cuenta hacia atras desde 10 hasta 1.
print("Cuenta regresiva de 10 a 1:")
for x in range(10,0,-1):
    print(x," ")
print("\n")

#5.Muestra la tabla de multiplicar del 7.
print("Tabla de multiplicar del 7:")
tabla=0
for tabla in range(1,11):
    producto= tabla* 7
    print("producto: ", producto)
print("\n")

#6. Suma todos los numeros del 1 al 100.
print("Suma del 1 al 100")
suma=0
for i in range(1,101):
    suma += i
    print(suma)
print("\n")

 #7.Calcula el factorial de un número dado
numero = int(input("Ingrese un numero:"))
fac = 1
for i in range(1, numero+1):
    fac*=i
    print(fac)

 #8.Puedes cambiar este número
numero = 5  
print(f"El factorial de {numero} es: {numero}(numero)")
print("\n")

#9.Imprime los números impares entre 15 y 30
print("Números impares entre 15 y 30:")
for i in range(15, 31):
    if i % 2 != 0:
        print(i)

print("\n")

#10.Muestra todos los años desde 1990 hasta 2025
print("Años desde 1990 hasta 2025:")
for año in range(1990, 2026):
    print(año)

print("\n")

#11.Imprime un cuadrado de asteriscos de 5x5
print("Cuadrado de asteriscos de 5x5:")
for _ in range(5):
     print("*****")