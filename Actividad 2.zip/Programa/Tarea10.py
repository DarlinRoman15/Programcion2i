# 4. Sumar dos números ingresados
num1 = float(input("Ingresa el primer número: "))
num2 = float(input("Ingresa el segundo número: "))
suma = num1 + num2
print(f"La suma de {num1} y {num2} es: {suma}")