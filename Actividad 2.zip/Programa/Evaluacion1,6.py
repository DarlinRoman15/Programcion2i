#Luego, solicita dos numeros enteros al usuario.
numero1=int(input("Introduce el primer numero entero:"))
numero2=int(input("Introduce el segundo numero entero:"))

suma= int(numero1) +int (numero2)
resta= int(numero1) -int (numero2)
multiplicacion= int(numero1) *int (numero2) 
division= int(numero1) /int (numero2)

print(f"la respuesta \nsuma es: {suma}, \nresta es: {resta}, \nmultiplicacion es: {multiplicacion}, \ndivicion es: {division}")