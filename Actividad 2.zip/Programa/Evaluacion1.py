#Solicite al usuario su nombre y edad usando la funcion input, muestra un saludo personalizado utilizando print.
nombre= input("cual es tu nombre:")
edad= input("cual es tu edad:")
print(f"Hola soy {nombre},tengo {edad} años")