x = int(input("Ingrese el primer numero: "))
y = int(input("Ingrese el segundo numero: "))
if x > 10 :
    if y > 20:
        print("y es mayor que 20")
else :
    print("x no es mayor que 10")