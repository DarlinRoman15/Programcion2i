#Enunciado
a = 5
b = 8
print("suma", a + b)
print("resta", a - b)
print("multiplicacion", a * b)
print("division", a / b) 